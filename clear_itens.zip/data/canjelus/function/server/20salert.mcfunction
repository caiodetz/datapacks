##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

tellraw @a [{"text":"Limpando itens dropados em ", "color":"yellow"}, {"text":"20 segundos", "color":"red"}, {"text":"...", "color":"yellow"}]
schedule function canjelus:server/10salert 10s

