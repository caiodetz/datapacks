##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

tellraw @a [{"text":"Limpando itens dropados em ", "color":"yellow"}, {"text":"4 segundos", "color":"red"}, {"text":"...", "color":"yellow"}]
schedule function canjelus:server/3salert 1s

