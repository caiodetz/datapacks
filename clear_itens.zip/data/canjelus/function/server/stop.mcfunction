##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

tellraw @a {"text":"Parando DataPack", "color":"red"}
schedule clear canjelus:server/clear_drop
schedule clear canjelus:server/1salert
schedule clear canjelus:server/2salert
schedule clear canjelus:server/3salert
schedule clear canjelus:server/4salert
schedule clear canjelus:server/5salert
schedule clear canjelus:server/10salert
schedule clear canjelus:server/20salert
schedule clear canjelus:server/30salert

