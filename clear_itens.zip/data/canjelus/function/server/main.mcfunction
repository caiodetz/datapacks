##
 # main.mcfunction
 # server
 #
 # Created by Canjelus_.
##
