##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

tellraw @a [{"text":"Limpando itens dropados em ", "color":"yellow"}, {"text":"2 segundos", "color":"red"}, {"text":"...", "color":"yellow"}]
schedule function canjelus:server/1salert 1s

