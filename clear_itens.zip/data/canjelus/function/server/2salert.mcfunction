##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

tellraw @a §eLimpando itens dropados em §c2 segundos§e...
schedule function canjelus:server/1salert 1s

