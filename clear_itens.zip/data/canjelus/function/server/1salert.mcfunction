##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

tellraw @a §eLimpando itens dropados em §c1 segundos§e...
schedule function canjelus:server/clear_drop 1s

