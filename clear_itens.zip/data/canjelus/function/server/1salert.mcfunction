##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

tellraw @a [{"text":"Limpando itens dropados em ", "color":"yellow"}, {"text":"1 segundo", "color":"red"}, {"text":"...", "color":"yellow"}]
schedule function canjelus:server/clear_drop 1s

