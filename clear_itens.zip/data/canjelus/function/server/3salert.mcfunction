##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

tellraw @a §eLimpando itens dropados em §c3 segundos§e...
schedule function canjelus:server/2salert 1s

