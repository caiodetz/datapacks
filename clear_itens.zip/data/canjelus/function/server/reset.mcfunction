##
 # reset.mcfunction
 # server
 #
 # Created by Canjelus_.
##
function canjelus:server/clear_drop