##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

tellraw @a §eLimpando itens dropados em §c30 segundos§e...
schedule function canjelus:server/20salert 10s

