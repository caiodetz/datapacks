##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

say §eLimpando itens dropados em §c4 segundos§e...
schedule function canjelus:server/3salert 1s

