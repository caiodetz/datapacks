##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

say §eLimpando itens dropados em §c5 segundos§e...
schedule function canjelus:server/4salert 1s

