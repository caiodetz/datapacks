##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

say §eLimpando itens dropados em §c20 segundos§e...
schedule function canjelus:server/10salert 10s

