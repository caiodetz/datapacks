##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

say §eLimpando itens dropados em §c1 segundos§e...
schedule function canjelus:server/clear_drop 1s

