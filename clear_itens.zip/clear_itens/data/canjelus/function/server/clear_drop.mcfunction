##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

say §cLimpando itens dropados...
kill @e[type=minecraft:item]
schedule function canjelus:server/30salert 3600s