##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

say §eLimpando itens dropados em §c30 segundos§e...
schedule function canjelus:server/20salert 10s

