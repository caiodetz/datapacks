##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

say §eLimpando itens dropados em §c3 segundos§e...
schedule function canjelus:server/2salert 1s

