##
 # clear_drop_itens.mcfunction
 # 
 #
 # Created by Canjelus_.
##

say §eLimpando itens dropados em §c10 segundos§e...
schedule function canjelus:server/5salert 5s

