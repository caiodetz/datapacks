##
 # restart.mcfunction
 # 
 #
 # Created by .
##
title @a title {"text":"Reiniciando...","color":"red","bold":true}
title @a subtitle {"text":"Servidor entrando em manutenção","color":"yellow"}
schedule function canjelus:server/stop 1s 