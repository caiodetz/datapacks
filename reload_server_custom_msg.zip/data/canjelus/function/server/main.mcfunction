##
 # main.mcfunction
 # server
 #
 # Created by canjelus.
##
