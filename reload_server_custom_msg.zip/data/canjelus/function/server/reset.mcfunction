##
 # reset.mcfunction
 # server
 #
 # Created by canjelus.
##
