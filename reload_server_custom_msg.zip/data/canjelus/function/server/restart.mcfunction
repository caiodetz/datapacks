##
 # restart.mcfunction
 # 
 #
 # Created by .
##
title @a title {"text":"Reiniciando em 15s","color":"red","bold":true}
title @a subtitle {"text":"Servidor entrando em manutenção","color":"yellow"}
schedule function canjelus:server/stopalert 15s 